# 商品 API 實作子對話可見文字快照

日期：2026-10-12。範圍與缺口見 README.md；保留可見文字與互動提問／答覆，不包含匯出之後的答覆、隱藏推理、其他工具全文或機器 metadata。以下可見對話原文不重寫成摘要。

## 1. 使用者

You are a subagent spawned by another session.
# 完成商品 CRUD 與原子關聯更新（已授權實作）
## 目標與本輪類型
正式實作：JSON商品新增、查詢、全部更新、刪除及四筆seed。使用者已授權，前置DB六表與Alembic已在PG18.6通過43測試，commit3351d8e存在。現在實作基本API，不加可選功能。
## 專案目錄與路徑基準
以下所有路徑以工作區根（~/workspace/agent/AGENTS.md所在層）為準；程式碼GainMiles_Test/，notes project-notes/。先确认真實目錄，不依賴cwd。權威卡project-notes/projects/GainMiles_Test/tasks/product-api.md。main已有commit且無staged，worker不commit。
## 必讀文件與必要背景摘要
GainMiles_Test/README.md、GainMiles_Test/docs/development-requirements.md（0.2，完整REST/邊界）、GainMiles_Test/docs/technical-decisions.md；project-notes/projects/GainMiles_Test/{overview,progress,plan}.md、research/python-product-api-stack.md、research/primary-key-and-input-compatibility.md（含PM補充）。讀實際GainMiles_Test/app/{config.py,db.py,models.py}、tests/conftest.py、requirements-dev.txt。實際URL從.env由程序讀但不可輸出。codePK備案未啟用。題目七欄Name/code/category/size/Unit price/inventory/color、每商品總價/庫存一值。
## 已確認／暫時假設／未知
已授權基本交付，default products.idPK/codeUNIQUE。環境.venv Python3.12.14、全部依賴已裝；db localhost55432/test55433均PG18.6已啟。一般帳號可連PG但不能Docker daemon；不sudo/改全機/啟停容器。屬性大小寫敏感可新增，code可改而id不變；未知期限。前置Base/get_engine/get_session_factory/get_session介面已存在；models Product.category為Category實體，sizes/Color集合，不是文字。
## 工作範圍與非目標
同步FastAPI route、schemas、services商品交易、分頁、seed、schema單元/OpenAPI/真PG整合測試。僅POST/GET/list/PUT/DELETE；不PATCH/filter/appDocker/variant/登入/新依賴/改DB schema/改README或docs。不得調整前置config/db/models/migration/共享conftest。API依賴用app.db.get_session，各request獨立Session。
## 需要的行為／輸入輸出／錯誤狀態
### JSON與解析
七可寫欄name(1–128),code(1–32),category(1–64),sizes,unit_price,inventory,colors；POST/PUT全必填，未知欄/null拒，id唯讀不收。字串trim，不自動限制code格式。sizes/colors輸入陣列或分隔字串，後者原始長度先限4096再以「、」「,」「，」切分（可混用），每項trim，1–50項，size每項1–32/color1–64，重複/空項422。不猜空白/CSV，陣列元素不拆且含三分隔符422。大小寫敏感，內部list[str]，response一律排序陣列。用Pydanticbeforevalidator/inputschemaanyOf[string,array]、responsearray，必驗OpenAPI。
unit_price收JSON數字或decimal字串，拒bool/物件/陣列、NaN/Infinity/負值/>99999999.99/>兩位有效小數；200.000可轉200.00，輸出兩位小數字串，用Decimal不float。inventory嚴格JSONint，拒bool/數字字串/小數，0..2147483647。input验证422detail陣列；NaN/Infinity出现在errors input時須安全JSON化、ctx ValueError轉safe形式，不能JSONResponse二次序列化变500。
### REST
/api/v1/products POST201+Location，GET/{id}200或404，GETlist200，PUT/{id}全部七欄替換200或404（不存在不新增），DELETE204無body再GET404。id>0integer，invalid422；code重複409 Product code already exists，notfound404 Product not found。列表limit20範圍1..100、offset0範圍0..100000，穩定id升序，{"items":[],"total":...,"limit":...,"offset":...}，total分页前，不多對多join重複。/docs与/openapi.json正常。
### 交易與錯誤
Category/Size/Color以PG ON CONFLICT DO NOTHING+查id取得或建立，穩定排序取多值減競爭；不增加管理API。所有寫入一transaction，UPDATE先SELECT FOR UPDATE锁商品再替換集合；衝突全部rollback含新增屬性。409只uq_products_code，其他IntegrityError不是code重複。Product輸出顯式映射category.name/sizes.code/colors.name排序，不假設from_attributes把實體轉字串。DBOperationalError/不可用/PoolTimeout回503 Database unavailable，unexpected500安全JSON，不洩SQL/堆疊/URL/密碼，不印active.env。
### seed
python -m app.seed，僅Star A-001 cloth S,M 200 20 Red,Blue；Moon A-002 cloth M,L 300 10 Red,White；Eagle B-001 pants M,L 100 23 Green；Bird B-002 pants S,M,L 50 12 Black。整批transaction，code存在只skip不覆寫，不每次啟動自灌；只輸出新增/skip數。services可復用但避免每筆自commit破壞整批。測試seed必只用專用PGsession／URL，不能測試中意外寫app庫。
## 可驗證的驗收
新增test_schemas.py無DB型別/邊界/OpenAPI；test_products.py真PG CRUD/transaction/seed。testclient局部fixture覆寫get_session，每request自己的test PGsession，沿用conftest migrated_engine/db_engine護欄，不改共享fixture、不mock掉主要CRUD。全部pytest-q（原43+新增）0skipped；詳矩陣每條實際測：201Location/404/409/422/204emptybody、price/inventory邊界、輸入array/string各三分隔及混合型態/4096-4097/50-51/null/dup/invalidlimits/unknownfields、GETtotal/排序/末頁、PUT變code保持id／全集合替換／共用屬性保留、衝突新增屬性全rollback、同名屬性併發不重複、同商品並發替換不混集合、seed二次四筆且修改後不覆寫。503/500可故障注入但不要求停真DB，錯誤response無私資訊；NaN/Infinity驗422JSON不是500。compile與OpenAPI覆核。不要只用壞格式body測到422卻未測指定位址成功。可啟本機API做curl但只是本輪新程序，不觸其他服務，log在.tmp。
## 限制與停止回報條件
不改全機、相依、schema、前置共享檔；若需要scope外修補或需求矛盾先回PM。既有source先讀。不sudo/Docker操作，不gitadd/commit/push，不繞hooks/換模型/另開session。公開docs不得本機路徑/PII/內部連結，本輪不改docs；notes由PM不寫。暫存工作區.tmp/gainmiles-implementation，不新增.local。先前worker曾輸出隨機.env舊密碼已輪替，嚴禁grep/print.env或在testfailure顯示URL。全測試需真PG，不以skip充當通過。
## 允許修改範圍／研究輸出路徑
僅GainMiles_Test/app/{main.py,schemas.py,seed.py}、GainMiles_Test/app/routers/、GainMiles_Test/app/services/、GainMiles_Test/tests/{test_products.py,test_schemas.py}。新子包__init__.py可在允許目錄。非tracked執行產物限現有.venv與工作區.tmp/gainmiles-implementation/；不得改README/docs、config/db/models/migrations、共享conftest、依賴或private index/notes。收工回報新增檔、驗收真結果/指令、session/database介面、未知／未完成；PM接手整合。

## 2. 助理

Baseline is green (43 passed). Now let me prototype the tricky schema/OpenAPI bits against the locked versions.

## 3. 助理

Prototype confirms the approach (input `anyOf`, output `array`/string, strict int, Decimal rules). Now writing the implementation.

## 4. 助理

Now the schema/OpenAPI tests (no DB):

## 5. 助理

Now the real-PostgreSQL integration tests:

## 6. 助理

All 206 pass. Let me check stability, compile, and the app database state before a manual API run.

## 7. 助理

Adding a few missing acceptance tests (case sensitivity at DB level, arbitrary code format, constraint discrimination):

## 8. 助理

Found a real gap: product ids beyond the INTEGER range hit a DB error and returned 500. Fixing by bounding the path parameter:

## 9. 助理

完成。以下是回報。

## 1. 做了什麼

在 `GainMiles_Test/`（工作區根 `~/workspace/agent/`）新增商品 API 的完整實作，未改任何前置檔案（`config.py`/`db.py`/`models.py`/`migrations/`/共享 `conftest.py`/`README`/`docs`/依賴）：

- **`app/schemas.py`**：`ProductCreate`（`extra="forbid"`，七欄必填）、`ProductRead`、`ProductPage`。`sizes`/`colors` 用 `field_validator(mode="before", json_schema_input_type=str | list[str])`，以「、」「,」「，」切分（可混用），原始字串先限 4096 再 trim，1–50 項、size 1–32／color 1–64、空項／重複／陣列元素含分隔符皆拒。`unit_price` 以 `BeforeValidator`+`AfterValidator`+`PlainSerializer` 實作（拒 bool/物件/陣列/非有限/負值/超上限/超兩位小數，`200.000`→`200.00`，JSON 輸出兩位小數字串，全程 `Decimal`）。`inventory` 用 `Field(strict=True)` 拒 bool／字串／小數。另提供 `sanitize_validation_errors()`，把 NaN/Infinity/exception `ctx` 轉成 JSON-safe。
- **`app/services/products.py`**：`insert_product`（共用、不 commit）、`create_product`、`get_product`、`list_products`、`update_product`、`delete_product`、`to_read`。屬性字典用 PG `INSERT … ON CONFLICT DO NOTHING` + 回查（值排序以穩定鎖序），更新以 `SELECT … FOR UPDATE` 鎖商品列後才替換集合；`IntegrityError` 只在 `diag.constraint_name == "uq_products_code"` 轉 `DuplicateCode`（409），其餘照實拋出。
- **`app/routers/products.py`**：`POST /api/v1/products`（201 + `Location`）、`GET /api/v1/products`（分頁物件）、`GET|PUT|DELETE /api/v1/products/{product_id}`；依賴 `app.db.get_session`。path id 限 `gt=0, le=2147483647`。
- **`app/main.py`**：掛 router；`RequestValidationError` → 422 安全 JSON；`OperationalError`/`InterfaceError`/`TimeoutError` → 503 `Database unavailable`；其他 → 500 `Internal server error`（不洩 SQL/URL/堆疊）。
- **`app/seed.py`**：`python -m app.seed`，四筆、整批一交易、code 已存在只 skip 不覆寫、只印新增/skip 數、失敗只印例外型別（不印 URL）。
- **`tests/test_schemas.py`（120）、`tests/test_products.py`（52）**：見下。

關鍵決定／踩到的坑：
1. `unit_price` 的 422 若照 FastAPI 預設序列化，NaN 會讓 Starlette `JSONResponse`（`allow_nan=False`）二次序列化失敗變 500 → 自訂 handler 先 sanitize。
2. PUT 時 `product.sizes = …` 會觸發 **query-invoked autoflush**，把尚未處理的 code 變更提早 flush 成 IntegrityError 且落在 try 之外 → 改為先 flush 純量欄位（在此攔截 code 衝突）再換集合。
3. 手動驗證時發現 `GET /products/2147483648`（超出 INTEGER 範圍）會 `DataError`→500，已把 path 參數限在 32-bit 範圍 → 現在 422。

## 2. 驗收結果

| 驗收項 | 指令／方式 | 結果 |
| --- | --- | --- |
| 全部測試、0 skipped | `.venv/bin/python -m pytest -q` | **215 passed**（原 43 + 新增 172），`0 skipped`；連跑 3 次結果一致 |
| 逐檔 | `--collect-only` | test_environment 26 + test_schema 17 + test_schemas 120 + test_products 52 = 215 |
| compile | `python -m compileall -q app tests` | OK |
| OpenAPI 覆核 | `app.openapi()` | 路徑 `/api/v1/products`、`/{product_id}`；request `sizes`/`colors` = `anyOf[string, array]`、`unit_price` = `anyOf[number,string]`、`additionalProperties: false`；response `sizes`/`colors` 只 `array`、`unit_price` `string`；DELETE 204 無 content |
| 真 PG CRUD | test_products 對 localhost:55433 | 201+Location、GET 200/404/422、409 `Product code already exists`、PUT 全替換且改 code id 不變、PUT 不存在 404 不新增、DELETE 204 body_bytes=0 後 GET 404 |
| 分頁 | API＋測試 | 預設 `{"items":[],"total":0,"limit":20,"offset":0}`；id 升序、total 分頁前、末頁空、多值商品不重複；limit 0/101、offset -1/100001 → 422 |
| 解析邊界 | 測試 | array/string 等價、三分隔符與混用、兩欄不同型態、單字串、空項/重複/混格式、4096→item 長度訊息、4097→4096 訊息、50 可/51 拒、size 33/color 65 拒 |
| 價格/庫存邊界 | 測試 | 0 與最大值可存；負值、200.001、>99999999.99、NaN/Infinity（HTTP 原始 `NaN`/`Infinity` body）→ 422 且可 JSON 解析、非 500 |
| 交易原子性 | 測試 | 409 後原 name/inventory/關聯完全保留、`brand-new-category`/`XL`/`Ultraviolet` 全數回滾；解析失敗不寫入任何列 |
| 併發 | 測試 | 同名 category/size/color 兩執行緒建立 → 各 1 列且兩商品共用同一 category_id；同商品兩並行 PUT → 最終集合等於完整請求之一，不混集 |
| seed | CLI 實跑＋測試 | 首跑 `seeded 3 …, skipped 1 existing`（因我先手動建了 A-001），二跑 `seeded 0 …, skipped 4 existing`；測試為 4/0 → 0/4，修改後重跑不覆寫 |
| 503 / 500 | 故障注入 | get_session 注入 OperationalError → 503 `{"detail":"Database unavailable"}`；monkeypatch service 拋 RuntimeError → 500 `{"detail":"Internal server error"}`，body 無 SQL/URL/Traceback |
| 真 API 程序 | uvicorn 127.0.0.1:8123（log 在 `.tmp/gainmiles-implementation/uvicorn.log`） | `/docs`、`/openapi.json` 200；24 個請求，log 無 traceback/500；已停止程序 |
| 公有/私有界線 | `git status` | 僅 7 個新 untracked 檔；`git diff` 無任何 tracked 修改；`.env` 未讀未印 |

未執行／未覆蓋：無 skip 充當通過；Docker 容器重建持久化、PATCH、篩選索引、app 容器、README 從零文件**未驗**（皆在本卡非目標）。

## 3. 沒做與原因

- **未 commit、未 staging、未 push**：依簡報 worker 不提交。
- **未寫任何 `project-notes/`**：本卡允許範圍僅列程式碼檔案且明示不得碰 private notes/index，故只回報、不落 notes（含 acceptance）。
- **未改** `config.py`/`db.py`/`models.py`/`migrations/`/`conftest.py`/`README`/`docs`/依賴（`git status` 可證）。
- 範圍外發現，僅記錄未修：
  - `starlette 1.7` + `httpx 0.28` 的 `TestClient` 會噴 `StarletteDeprecationWarning`（建議改用 httpx2）；屬環境既有，非本輪引入，全套 1 warning。
  - 手動 `curl` 驗證在 **app 資料庫**（localhost:55432）建立了 3 筆並跑 seed，最終狀態為四筆正式範例（A-001/A-002/B-001/B-002，值為 canonical）。原本該庫為 0 筆；若交卷前希望維持空庫，請 PM 決定是否清空。
- 需注意（限制）：`test_products.py` 需真 PG（`TEST_DATABASE_URL`），缺 URL 時 conftest 只 skip、無法當通過；本輪實際有連上，故 0 skipped。

## 4. 修改檔案清單

**public 程式碼（皆未 commit，只有 untracked 新檔）**
- 新增 `GainMiles_Test/app/main.py`
- 新增 `GainMiles_Test/app/schemas.py`
- 新增 `GainMiles_Test/app/seed.py`
- 新增 `GainMiles_Test/app/routers/__init__.py`、`app/routers/products.py`
- 新增 `GainMiles_Test/app/services/__init__.py`、`app/services/products.py`
- 新增 `GainMiles_Test/tests/test_schemas.py`、`tests/test_products.py`
- 未修改任何既有 tracked 檔

**private notes**：無（依簡報未寫、未 add）。

**執行產物（非 tracked，未 stage）**：`.tmp/gainmiles-implementation/{uvicorn.log,proto_schemas.py,debug_put_conflict.py}`

**介面備註給 PM**：API 依賴為 `app.db.get_session`（每 request 一 Session，`expire_on_commit=False`）；services 一律接受外部 `Session` 並自行 commit/rollback；測試以 `app.dependency_overrides[get_session]` 換成綁定 `db_engine`（conftest 護欄）的 sessionmaker，未改共享 fixture、未 mock CRUD。

## 10. 使用者

## 目標與本輪類型
正式實作小修：PM已讀源碼且重跑215pass，修兩個具體契約差異；不擴功能。
## 專案目錄與路徑基準
工作區根~/workspace/agent/AGENTS.md以下相對；code GainMiles_Test/、notes project-notes/，先確認目錄。續同一API任務；不同READMEworker同時只改README與live demo，不修改你的檔或使用testDB。你只用測試DB，不touchapp庫。
## 必讀文件與必要背景摘要
GainMiles_Test/app/schemas.py、app/seed.py、tests/test_schemas.py、tests/test_products.py、docs/development-requirements.md。PGtest55433仍在、.venv3.12.14已裝，215pass；PM8123程序仍用前版，不要停它，這輪實作需PM之後重啟自己的API才新碼。READMEworker在做liveHTTP appdemo，彼此不同DB。
## 已確認／暫時假設／未知
標準422detail loc應保留FastAPI既有的str/int混合；目前sanitize_validation_errors把所有locpart轉str，會把JSON decode位置offset整數變文字，是contract『標準detail陣列』差異。seed main RuntimeError目前print f'{error}'，雖既有例外文字固定安全，契約是失敗只printtype，不將未來RuntimeError內容印出。
## 工作範圍與非目標
僅兩處安全正確性修補與對應測試。不schema/依賴/README/額外feature/尚未授權PATCH。
## 需要的行為／輸入輸出／錯誤狀態
1 sanitize_validation_errors 的loc保留str/int原型態；不用str()改所有項。安全JSON轉換僅用在input/ctx等不合法NaN，fallback罕見非str/int可安全轉換但正常loc應與FastAPI一致。新增人工error loc ('body','sizes',0)整數0仍0，以及HTTP invalidJSON位置offset仍int/422JSON。
2 seed main RuntimeError只印type或白名單安全訊息，不print任意error原文；與SQLAlchemyError保持credential-free。unit故障注入RuntimeError含動態隨機sentinel（不能用真实envURL或credential），assert output無sentinel且exit1；依要求不硬編碼測試密碼。
## 可驗證的驗收
tests_schemas + test_products +全pytest都pass0skip，原215不回歸，新增測試數真實回報；malformedJSON422保持locint。修改scope4檔且無app庫mutation/noDocker操作。compilerpass。此輪API程序未重啟，要說明新碼須重啟。不以stdout全篇印active.env/URL。
## 限制與停止回報條件
不sudo/daemon/全機、停PM8123、改任何前置source/env/notes/index/README；不gitadd/commit/push。不加依賴，scope外回PM。
## 允許修改範圍／研究輸出路徑
僅 GainMiles_Test/app/schemas.py、GainMiles_Test/app/seed.py、GainMiles_Test/tests/test_schemas.py、GainMiles_Test/tests/test_products.py；非trackedtmp工作區.tmp/gainmiles-implementation/。READMEworker不動這些檔，避免操作appDB。

## 11. 助理

Reading the exact current code before editing:

## 12. 助理

Let me prove the new tests actually catch the old behaviour (temporarily reverting, then restoring):

## 13. 助理

兩處修補完成，回報如下。

## 1. 做了什麼

只改簡報允許的 4 個檔，兩個契約差異各一處修補，未動 schema／依賴／README／前置檔，未新增功能：

**修補 1 — `app/schemas.py`：422 detail 的 `loc` 保留 FastAPI 原型態**
新增 `normalize_loc_part()`：`str`／`int` 原樣保留，只有罕見非 `str`/`int` 的 part 才走 `json_safe()`。原本 `"loc": [str(part) for part in error.get("loc", ())]` 會把 JSON decode 的 offset 整數變成字串，與「標準 FastAPI 驗證錯誤陣列」不符。`input`／`ctx`／`msg`／`url` 的安全 JSON 轉換（NaN/Infinity、exception 物件）完全保留，未放寬。

**修補 2 — `app/seed.py`：`main()` 的 RuntimeError 只印型別**
`print(f"seed failed: {error}")` → `print(f"seed failed: {type(error).__name__}")`，與既有的 `SQLAlchemyError` 分支一致；不再把任意 RuntimeError 原文寫進 stdout。`DATABASE_URL` 未設時現在輸出 `seed failed: RuntimeError`（不再帶提示文字），這是契約要求的取捨。

**測試（新增 5 條，真實回報）**
- `tests/test_schemas.py` +3：
  - `test_sanitize_validation_errors_preserves_loc_types`：人工 error `loc=("body","sizes",0)` → 回 `["body","sizes",0]` 且 `0` 是 `int`。
  - `test_sanitize_validation_errors_sanitises_nan_but_keeps_loc`：NaN `input` → `"nan"`、`ctx` 的 ValueError → `"boom"`，`loc` 不變，`json.dumps(..., allow_nan=False)` 可序列化。
  - `test_invalid_json_body_keeps_integer_offset_in_loc`：HTTP 送 `{not json` → 422，`detail[0]["type"]=="json_invalid"`，`loc == ["body", 1]` 且 `1` 是 `int`。
- `tests/test_products.py` +2：
  - `test_seed_main_prints_only_the_exception_type`：monkeypatch `app.db.get_session_factory` 拋 `RuntimeError(f"...{sentinel}")`，sentinel 由 `secrets.token_urlsafe(16)` 動態產生（無硬編碼密碼／URL）；assert exit 1、stdout/stderr 皆無 sentinel、輸出為 `seed failed: RuntimeError`。
  - `test_seed_main_hides_sqlalchemy_error_detail`：注入 `OperationalError("SELECT 1", {}, Exception(sentinel))`；assert exit 1、無 sentinel、輸出 `seed failed: OperationalError`。

## 2. 驗收結果

| 驗收項 | 指令 | 結果 |
| --- | --- | --- |
| 全套測試、0 skip、無回歸 | `.venv/bin/python -m pytest -q`（連跑 3 次） | **220 passed**，0 skipped（原 215 + 新 5） |
| 新增測試真實 | `-k` 精選 5 條 | `5 passed, 215 deselected` |
| 逐檔收集 | `--collect-only` | test_schemas 123（+3）、test_products 54（+2）、原環境/schema 43 |
| **回歸有效性驗證** | 暫回舊碼跑 3 條新測試 | `3 failed`（loc int 變 str、offset 變 str、sentinel 被印出），還原後 220 passed → 測試確實抓得住舊行為 |
| malformed JSON loc 仍 int | HTTP + 人工 error | `loc=["body",1]`（int）、`["body","sizes",0]`（int 0） |
| compile | `python -m compileall -q app tests` | OK |
| 修改範圍 | `git status --short` / `git diff --stat` | 我這側僅 `app/schemas.py`、`app/seed.py`、`tests/test_schemas.py`、`tests/test_products.py` 共 4 檔（+21/-2、+4/-2、+49、+39） |
| app 庫 | 本輪未連線 | 全部只跑 pytest（test DB 55433）；未執行 `python -m app.seed`、未啟任何 API、未讀 `.env`、未輸出任何 URL/密碼 |
| PM 8123 程序 | 未觸碰 | 未停止、未重啟、未連該埠 |

**注意（需 PM 動作）**：PM 目前的 8123 API 程序仍在跑**上一版**程式碼，`sanitize_validation_errors` 的 `loc` 修補要**重啟該 API 程序**才會生效；`app/seed.py` 是可重跑 CLI，下次執行即為新行為。

補充觀察：`git log` 顯示 PM 已把我上一輪成果提交為 `4199a90`，所以這 4 檔現在是 tracked 且為 modified；`git status` 另顯示 `README.md` 為 modified，那是 README worker 的改動，**我未讀寫該檔**。

## 3. 沒做與原因

- 未 commit／未 stage／未 push（簡報禁止）。
- 未寫任何 `project-notes/`（本卡允許範圍只有上述 4 檔 + `.tmp/gainmiles-implementation/`）。
- 未處理範圍外項目（`RuntimeError` 的「白名單安全訊息」我選擇只印型別；若 PM 想保留「請先建立 .env」提示，需另立白名單設計，屬另一輪）。
- 既有 1 個 `StarletteDeprecationWarning`（starlette 1.7 + httpx 0.28 TestClient）仍在，屬環境既有、非本輪引入。
- 未驗 app Docker、容器持久化、PATCH、篩選：皆在本卡非目標／未授權。

## 4. 修改檔案清單

**public 程式碼（modified，未 commit）**
- `GainMiles_Test/app/schemas.py` — 新增 `normalize_loc_part()`、`sanitize_validation_errors()` 保留 loc 原型態
- `GainMiles_Test/app/seed.py` — `main()` RuntimeError 分支只印型別
- `GainMiles_Test/tests/test_schemas.py` — +3 測試
- `GainMiles_Test/tests/test_products.py` — +2 測試（含 `secrets`、`app.db`、`app.seed` import）

**private notes**：無（未寫、未 add）。

**執行產物**：本輪無新增（暫回的 `.bak` 已刪除）；`.tmp/gainmiles-implementation/` 內僅留前輪的 `uvicorn.log`、`proto_schemas.py`、`debug_put_conflict.py`。
