# 主鍵與字串相容研究子對話可見文字快照

日期：2026-10-12。範圍與缺口見 README.md；保留可見文字與互動提問／答覆，不包含匯出之後的答覆、隱藏推理、其他工具全文或機器 metadata。以下可見對話原文不重寫成摘要。

## 1. 使用者

You are a subagent spawned by another session.
## 目標與本輪類型
研究：為既有規劃补核 PostgreSQL code 主鍵、Alembic 備案隔離、Pydantic 字串轉陣列；只查證並寫筆記，不實作。
## 專案目錄與路徑基準
工作區根由 ~/workspace/agent/AGENTS.md 確認；以下以工作區根為基準。程式碼 GainMiles_Test/，notes project-notes/。先確認真實目錄，不依賴 cwd。
## 必讀文件與必要背景摘要
GainMiles_Test/docs/development-requirements.md、GainMiles_Test/docs/technical-decisions.md；project-notes/projects/GainMiles_Test/{overview,progress,plan}.md。既有 default 是 products.id 整數 PK，code 唯一可修改；映射 product_id FK；API /api/v1/products/{id}，數字 id，輸出 id；sizes/colors 原本只陣列。使用者僅規劃，要求 code 當 PK 的 migration 備案，以及是否可輸入 "Blue、Red"。
## 已確認／暫時假設／未知
確認題目沒說 PK，沒有程式、Git code repo、DB。假設預設仍 idPK，新備案 code-only PK（不留 products.id），兩映射改 product_code 字串 FK ON UPDATE CASCADE/ON DELETE CASCADE；API code 地址為 /api/v1/products/by-code/{code}，JSON 不輸出 id，列表 code 升序，修改 code 時用舊URL且新Location，其他七欄不變。另一折衷 codePK但保留idUNIQUE可保持numeric API，屬不同方案不是本備案。未知考官指定PK意圖，不揣測評分。
## 工作範圍與非目標
只核對官方細節：PG PK可文字、FK可reference unique、ON UPDATE CASCADE；SQLAlchemy mutable PK/passive_updates；Alembic 不應把互斥初始revision放同default歷史，獨立script_location/config比無考慮upgrade heads安全；Pydantic v2 field_validator(mode=before)配list[str]|str輸入OpenAPI及仍list輸出。不要寫migration.py、不安裝、不啟動服務、不改公文、不做完整重新技術選型。
## 需要的行為／輸入輸出／錯誤狀態
拟定 sizes/colors 支援JSON陣列或分隔字串，分隔符「、」「,」「，」，trim後每项非空、重複422、1–50項；單字串"Blue"為單元素，不推論空白是分隔符；陣列元素視完整標籤不拆，例如["Blue、Red"]422避免混格式；為一致性標籤禁這三分隔符；輸出一律陣列。聚合字串長度上限 sizes1697(colors3297)依50*每项maxlength+49 delimiter只是未trim空白時需設更寬或說明拒絕；請建議明確可驗收上限如4096而不是無界限。code-only URL 僅接受code ASCII safe charset [A-Za-z0-9._-] 1–32但排除精确 . ..，這是備案新假設，不能偷偷改預設code任意字串規格。只說事實／推論／未知，列風險。
## 可驗證的驗收
寫單一繁中筆記，日期2026-10-12，至少PG/Alembic/Pydantic三官方原始來源及要點；不要摘不存在的API。需清楚說不只改migration，code-only會動ORM/FK/routes/schemas/tests與排序。不用套件實測，所有例碼未執行。外部研究先查官方，完成後才比對舊研究（此專案python-product-api-stack.md含先前資料）；有矛盾只回報，不改舊文。
## 限制與停止回報條件
使用者未授權任何實作，禁止implementer和服務、套件安裝；不能git add/commit/push，不寫機密/PII/帳號ID/本機絕對路徑。來源拿不到標未知，不擅自選新模型或工具鏈。
## 允許修改範圍／研究輸出路徑
只可寫 project-notes/projects/GainMiles_Test/research/primary-key-and-input-compatibility.md；其他僅讀。PM 整合提交。

## 2. 助理

I'll start by verifying the environment and required files, then do external research on official sources.

## 3. 助理

Let me read the required background files.

## 4. 助理

Now let me read the existing research note and architecture spec (I'll do external verification from official sources first, then compare).

## 5. 助理

Now I'll do external research on official sources. Starting with PostgreSQL official docs on constraints.

## 6. 助理

PostgreSQL facts captured. Now the SQLAlchemy and Alembic official docs.

## 7. 助理

Now Pydantic validators, Alembic cookbook (multiple environments), and SQLAlchemy mutable-primary-key page.

## 8. 助理

Now the Alembic multiple-environments recipe and PostgreSQL index type notes.

## 9. 助理

Now the Pydantic unions doc and the required old-notes grep.

## 10. 助理

One more official source on collation (matters for text PK equality/ordering).

## 11. 助理

I have all official sources. Now writing the note.

## 12. 助理

完成。研究只查證官方來源並沉澱成單一筆記，未實作、未安裝、未動 Git。

## 交出的檔案
- `project-notes/projects/GainMiles_Test/research/primary-key-and-input-compatibility.md`（唯一寫入；日期 2026-10-12；339 行）
- 已確認：路徑落在允許範圍、無本機絕對路徑／憑證／email、未對 `project-notes/` 做任何 `git add/commit`。

## Brief 核對
問題／範圍／來源／輸出路徑／完成條件五項皆齊，無缺漏、無矛盾，且輸出路徑符合允許範圍，故直接執行。

## 官方查證要點（實測？否，全部僅讀文件）
**事實（來源附於筆記）**
- **PostgreSQL 18**：主鍵不限整數，PK 自動建 unique B-tree；FK 可 reference **non-deferrable unique 或 PK**；`ON UPDATE CASCADE` 會把新值複製到引用列；**FK 欄位不自動建索引**；`ORDER BY`/等值受 collation 影響，預設 collation 為 deterministic（ASCII 大小寫敏感），但非 C locale 排序非 byte 序。
- **Alembic 1.20**：多 head 時 `upgrade head` **失敗**（原文錯誤訊息）、`heads` 會同時套用、`merge` 是合併語意；官方 cookbook 的 `alembic --name <section>` 可讓每個 `script_location` 擁有**各自 `alembic_version`**（注意不吃 `pyproject.toml`）。
- **SQLAlchemy 2.0**：`passive_updates` 預設 `True`，建議可變主鍵交給 DB `ON UPDATE CASCADE`，`False` 無法多層 cascade；範例 `ForeignKey(..., onupdate="cascade")`。
- **Pydantic v2**：`field_validator(mode='before')` 在型別驗證前改寫輸入；JSON Schema 預設沿用欄位型別、可用 `json_schema_input_type` 覆寫為 `anyOf`；配 union 有「就地改輸入」警告；FastAPI OpenAPI 由 Pydantic JSON Schema 產生。
- **RFC 3986**：unreserved = `ALPHA/DIGIT/-/./_/~`；`.` 與 `..` 為特殊 dot-segments。

**已明講「不只改 migration」**：code-only 會連動 ORM／FK（`product_code` + `ON UPDATE/DELETE CASCADE`）／routes（`/products/by-code/{code}`）／schemas（移除 id）／排序（`code` 升序）／測試與 seed；並把 ASCII 字元集、by-code URL、改 code 的舊 URL/新 Location 全部標成**備案新假設**，告誡不得回改預設規格。

## 舊筆記對照（先研後對照）
- 掃描後同主題舊筆記為 `python-product-api-stack.md`（含 PM 勘誤）；其餘命中為不同堆疊或無關旁述。
- 判定：**一致（互補）；無出入**。舊筆記的 PG「PK/UNIQUE 自動索引、FK 不自動」等與本輪官方查證一致，且未涵蓋本輪新主題（文字 PK、`ON UPDATE CASCADE`、Alembic 多 head、`field_validator`），故無需勘誤、我只回報不寫入舊檔。

## 需要你拍板的點
1. 備案數字對帳：本簡報 `sizes 1697 / colors 3297` 與我算的嚴格值 `1649 / 3249` 差 **48/48**，差額可用「每個分隔符最多多 1 個空白」的寬鬆算法（`50×L + 97`）解釋；我建議對外只宣告**單一上限 4096（trim 後）**，避免這條模糊空間。
2. 是否採用 code-only PK？sizes/colors 是否真的要收字串輸入？改 code 的 URL/Location 語義？兩份 Alembic 環境要不要長期保留？（筆記末已列「待 PM 決策」）
