# GainMiles Python Online Test

1. Here is a table which has information of the product, please refer to the table to design the table schema and RESTful API.
   * The API can create、update、read and delete data.
   * The format is JSON.
   * Please use docker to install a RDBMS.
   * Please write the command of running service in README

* If you use AI, please provide the entire conversation for reference
* It is not necessary to complete all tasks. Please submit this test within the given time.

| Name | code  | category | size     | Unit price | inventory | color       |
| :--- | :---- | :------- | :------- | :--------- | :-------- | :---------- |
| Star | A-001 | cloth    | S、M     | 200        | 20        | Red、Blue   |
| Moon | A-002 | cloth    | M、L     | 300        | 10        | Red、White  |
| Eagle| B-001 | pants    | M、L     | 100        | 23        | Green       |
| Bird | B-002 | pants    | S、M、L  | 50         | 12        | Black       |
| .... |       |          |          |            |           |             |
